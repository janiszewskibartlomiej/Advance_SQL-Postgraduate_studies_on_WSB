
Truncate table SuperstoreLanding.dbo.DIM_PRODUCT_LANDING;

BULK INSERT SuperstoreLanding.dbo.DIM_PRODUCT_LANDING
FROM 'C:\Pankrac\WSB\Advanced_DB&DWH_Zajecia3\projekt_Superstore\ODS\Source\Products.txt' 
WITH (FIELDTERMINATOR= '|', ROWTERMINATOR = '\n', FIRSTROW = 2);