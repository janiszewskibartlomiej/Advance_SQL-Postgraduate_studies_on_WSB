use SuperstoreLanding
go

CREATE OR ALTER PROC proc_DimCustomerLandingLoad  

as

begin 

Truncate table SuperstoreLanding.dbo.DIM_CUSTOMER_LANDING;

BULK INSERT SuperstoreLanding.dbo.DIM_CUSTOMER_LANDING
FROM 'C:\Pankrac\WSB\Advanced_DB&DWH_Zajecia3\projekt_Superstore\Landing\Source\Customers.csv' 
WITH (FORMAT='CSV', FIRSTROW = 2);

end 
go